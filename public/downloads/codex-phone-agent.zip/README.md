# 接入另一台电脑

这份文档用于把另一台安装了 Codex 的电脑接入你自己的 Codex 随行服务器。把下面的 `https://your-domain.example` 替换成你的实际网址。

服务端 0.6.0 支持独立账号。请先登录你自己的账号，再生成配对码；不要使用其他用户或管理员的配对码。现有 0.5.0 连接程序仍兼容，服务器升级不要求已绑定电脑重新配对。

## 要求

- Node.js 24 或更高版本。
- 当前电脑已经安装并能运行 Codex。
- 当前电脑能访问你的 HTTPS 网站。
- 不复制其他电脑的 Codex 配置、设备令牌或 `.data` 目录。

## 下载源码

可以直接从 GitHub 克隆本项目，或下载对应版本压缩包：

```sh
git clone https://github.com/wang1733238039/codex-phone.git
cd codex-phone
npm ci --ignore-scripts
```

Windows 连接程序已有实机验证；macOS 提供安装分支但尚未实机验收，Linux 连接端暂未验证。

## 配对

在手机网页的“添加电脑”中生成一次性配对码，然后在这台电脑执行：

```sh
node tools/pair.mjs --server https://your-domain.example --name "办公室电脑"
```

按提示输入配对码。配对成功后，配置保存在本机 `.data/agent.remote.json`。不要把这个文件发给其他人，也不要提交 Git。

若无法自动找到 Codex，可以增加 `--codex-bin` 指定实际可执行文件路径；Windows 必须指定 `codex.exe`。`--codex-home` 可指定本机 Codex 数据目录。支持 `--code-file` 从 UTF-8 临时文件读取配对码，成功后自行删除该文件。已有配对配置会被保留，不会自动覆盖。

启动连接程序：

```sh
node tools/remote-agent.mjs
```

Windows 可运行 `start-remote-agent.ps1`，并用 `install-remote-autostart.ps1` 配置当前用户登录自启。

## Windows 桌面入口与开机自启

配对后执行一次：

```powershell
node tools/install-connector.mjs
```

会在桌面和开始菜单创建 **Codex 随行 - 电脑连接** 快捷方式，同时开启当前用户登录自启：

- 双击快捷方式，打开连接管理窗口并在需要时启动后台连接。重复打开不会启动第二个连接进程。
- 勾选“登录 Windows 后自动启动连接”，以后重启并登录 Windows 后自动连接；取消勾选即可关闭自启，当前连接继续运行。
- 关闭管理窗口不会停止后台连接；电脑关机、休眠后暂停，恢复联网时连接端会重试。
- Windows 后台守护独立于启动它的终端和 Codex：优先用当前用户计划任务托管；系统拒绝注册计划任务时，自动使用 Explorer 启动的隐藏守护和登录启动项。连接进程或内层守护退出后会自动恢复，恢复检查间隔约 20 秒。配对配置和电脑身份不变。
- 窗口显示本机连接进程和后台守护状态。服务器的真实在线状态以手机电脑列表为准。
- “打开手机网页”使用本机配对的网址；“查看日志”打开本机 `.data` 目录，分享日志时不要把同目录的凭据文件一起发出。

程序仍在当前安装目录，快捷方式只是入口。不要删除或移动该目录；如需移动，保留本机私有配置并在新位置重新安装快捷方式和自启动。

也可以单独安装入口、切换自启动：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-connector-shortcuts.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-remote-autostart.ps1 -NoStart
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-remote-autostart.ps1 -Disable
```

`-Disable` 只关闭此安装目录拥有的登录及定期启动触发器，不停止当前连接，也不修改其他安装目录的入口。自启在登录当前 Windows 用户后发生，电脑仍须保持开机、联网且 Codex 可用。

升级已有 Windows 安装时，保留原目录和 `.data/agent.remote.json`，更新程序后再次运行 `node tools/install-connector.mjs`。仅 `git pull` 不会替换已经运行的后台守护；无手机连接程序持有的任务时可重启连接程序，桌面 Codex 无需退出。取消自启后，当前后台守护仍运行；独立守护本身被手动结束时，登录启动项方案需要双击桌面入口或重新登录恢复。

## 验证

0.6.11 兼容 Codex 自动压缩后的 `.jsonl.zst` 历史。旧版本会因原 `.jsonl` 不存在而误报“状态未确认”、打不开内容或禁止发送。升级连接程序即可恢复识别，无需解压或改写 Codex 数据。超长主对话通过原生接口读取最近消息；原工作目录已删除的对话仍仅支持查看。

0.6.9 起，Windows 连接程序也支持桌面右侧的临时侧栏对话。手机打开主对话后，从“子对话”切换，展示最近 15 条输入和最终回复；发送使用原桌面通道，执行中可选择“补充本轮”，暂不支持临时侧栏排队。桌面关闭临时侧栏后，该对话可能无法恢复，请在主对话继续沟通。首次连接会从最近七天的桌面日志寻找候选，再由原桌面核验归属；不会将日志正文上传到服务器。

0.6.10 修复桌面打开父对话时手机无法新建子对话的问题。优先使用原生附着分支；桌面明确拒绝附着时，使用继承上下文的原生分支，核验原生日志中的父子关系后加入手机子对话列表。此兼容分支可能在桌面普通会话列表中显示，不保证成为桌面右侧临时窗口。关联与历史边界保存在电脑 Codex 数据目录的 `.codex-phone-children.json`，升级或迁移时保留该文件。临时侧栏本身不能再次分支，请返回主对话新建。

网页中断后，“新建子对话”会改为“核对上次创建结果”。点击会查询原请求，成功后打开已有子对话，避免重复创建；已明确失败的请求可以重新发起。

回到手机网页，电脑列表应显示新设备在线。打开一个项目和会话，先只发送一条无副作用的测试消息，确认回复和状态正常后再继续使用。

电脑关机、休眠或连接程序退出时，手机仍可查看服务器已有缓存，但不能取得新的本地会话或执行新任务。

## 更新

更新前先停止本安装目录的连接程序，保留 `.data/agent.remote.json`，再更新源码并执行：

```sh
npm ci --ignore-scripts
node tools/remote-agent.mjs
```

不要删除 `.data` 来解决问题；需要重新绑定时，应先在网页解绑旧设备，再按配对流程生成新令牌。
